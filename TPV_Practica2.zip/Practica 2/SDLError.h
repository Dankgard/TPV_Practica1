#pragma once

#include "ArkanoidError.h"

class SDLError : public ArkanoidError {
protected:

public:

};
