#pragma once

#include "ArkanoidError.h"

class FileNotFoundError : public ArkanoidError {
protected:

public:

};
