#pragma once

#include "ArkanoidError.h"

class FileFormatError : public ArkanoidError {
protected:

public:

};
