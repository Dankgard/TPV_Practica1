#include <iostream>
#include "GameObject.h"
#include "checkML.h"

using namespace std;

void GameObject::render() {

}

void GameObject::update() {

}

void GameObject::handleEvents(SDL_Event event) {

}