#pragma once

#include "ArkanoidError.h"
#include "checkML.h"

class SDLError : public ArkanoidError {
protected:

public:

};
