#pragma once

#include "ArkanoidError.h"
#include "checkML.h"


class FileFormatError : public ArkanoidError {
protected:

public:

};
