#include <iostream>
#include "GameObject.h"
#include "checkML.h"

using namespace std;

GameObject::GameObject() {}

GameObject::~GameObject() {}